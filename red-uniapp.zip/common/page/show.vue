<template>
	<view class="container">
		show
	</view>
</template>

<script>
</script>

<style>
</style>