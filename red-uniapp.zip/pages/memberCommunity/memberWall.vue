<template>
	<view>
		<view class="picker">
			<u-picker :show="show1" :columns="columns1" @change="change" @cancel="cancel" @confirm="confirm"></u-picker>
			<u-button @click="show1 = true">{{select}}</u-button>
		</view>
		<view class="listShow">
			<view class="ul" v-for="(item, index) in listShow" :key="index">
				<view class="li" v-if="seletion==='全部职位' || item.userInfo.level === seletion">
					<image :src="item.url" mode="widthFix"></image>
					<view class="text">
						<text class="uname">{{item.userInfo.name}}</text>
						<text class="other">{{item.userInfo.area}} | {{item.userInfo.level}}</text>
						<text
							class="honor">{{item.userInfo.honor}}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show1: false,
				select: '选择职位',
				seletion: '全部职位',
				columns1: [
					['全部职位','普通党员', '党支部书记', '其他']
				],
				listShow: [{
					url: '../../static/images/头像.png',
					show: true,
					userInfo: {
						name: '张立',
						honor: '个人简介：服务意识强，民主作风好，能团结、关心、爱护同志，能做到廉洁自律。能够树立大局意识、服务意识、使命意识，努力把“全心全意为人民服务”的宗旨体现在日常工作之中;能够深入了解党员、教职工尤其是广大青年学生的思想状况，帮助他们解决一些工作、学习与生活上的困难，受到大家的称赞。为人正派，胸怀大度。注意廉洁自律，不做违反党纪党规的事，切实做好表率作用。',
						level: '普通党员',
						area: '深圳'
					},
				},{
					url: '../../static/images/头像.png',
					show: true,
					userInfo: {
						name: '张立',
						honor: '个人简介：服务意识强，民主作风好，能团结、关心、爱护同志，能做到廉洁自律。能够树立大局意识、服务意识、使命意识，努力把“全心全意为人民服务”的宗旨体现在日常工作之中;能够深入了解党员、教职工尤其是广大青年学生的思想状况，帮助他们解决一些工作、学习与生活上的困难，受到大家的称赞。为人正派，胸怀大度。注意廉洁自律，不做违反党纪党规的事，切实做好表率作用。',
						level: '普通党员',
						area: '深圳'
					},
				},{
					url: '../../static/images/头像.png',
					show: true,
					userInfo: {
						name: '李武',
						honor: '个人简介：服务意识强，民主作风好，能团结、关心、爱护同志，能做到廉洁自律。能够树立大局意识、服务意识、使命意识，努力把“全心全意为人民服务”的宗旨体现在日常工作之中;能够深入了解党员、教职工尤其是广大青年学生的思想状况，帮助他们解决一些工作、学习与生活上的困难，受到大家的称赞。为人正派，胸怀大度。注意廉洁自律，不做违反党纪党规的事，切实做好表率作用。',
						level: '党支部书记',
						area: '深圳'
					},
				},{
					url: '../../static/images/头像.png',
					show: true,
					userInfo: {
						name: '张立',
						honor: '个人简介：服务意识强，民主作风好，能团结、关心、爱护同志，能做到廉洁自律。能够树立大局意识、服务意识、使命意识，努力把“全心全意为人民服务”的宗旨体现在日常工作之中;能够深入了解党员、教职工尤其是广大青年学生的思想状况，帮助他们解决一些工作、学习与生活上的困难，受到大家的称赞。为人正派，胸怀大度。注意廉洁自律，不做违反党纪党规的事，切实做好表率作用。',
						level: '普通党员',
						area: '深圳'
					},
				}, ]
			};
		},
		methods: {
			change(e) {
				// console.log('change', e);
			},
			showPicker(index) {
				this.show1 = true
			},
			confirm(e) {
				console.log('confirm', e.value[0]);
				this.select = e.value[0]
				this.seletion = e.value[0]
				this.show1 = false
			},
			cancel() {
				// console.log('cancel');
				this.show1 = false
			},
		}
	}
</script>

<style scoped>
	.li {
		background-color: #fefefe;
		padding: 20rpx 10rpx;
		margin: 10rpx 0;
	}

	.li image {
		width: 180rpx;
		height: 180rpx;
		float: left;
		margin: 20rpx;
	}

	.li .uname {
		/* font-size: 30rpx; */
		font-weight: 800;
		display: block;
	}

	.li .other {
		display: block;
		font-size: 30rpx;
	}

	.li .honor {
		font-size: 28rpx;
		color: #bebebe;
		overflow: hidden;
		display: -webkit-box;
		-webkit-line-clamp: 4;
		/* 指定显示的行数 */
		-webkit-box-orient: vertical;
	}

	.li .text {
		margin: 20rpx 30rpx;
	}
</style>