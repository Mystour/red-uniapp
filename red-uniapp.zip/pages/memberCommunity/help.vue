<template>
	<view class="content">
		<view class="u-demo-block">
			<text class="u-demo-block__title">帮扶学生基本信息，提交后不可修改，请核对无误后提交</text>
			<view class="u-demo-block__content">
				<!-- 注意，如果需要兼容微信小程序，最好通过setRules方法设置rules规则 -->
				<u--form labelPosition="left" :model="model1" ref="form1">
					<u-form-item label="姓名" prop="userInfo.name" borderBottom ref="item1">
						<u--input v-model="model1.userInfo.name" border="none" placeholder="姓名,只能为中文"></u--input>
					</u-form-item>
					<u-form-item label="专业班级" prop="userInfo.department" borderBottom ref="item2">
						<u--input v-model="model1.userInfo.department" border="none"
							placeholder="21计算机科学与技术3班"></u--input>
					</u-form-item>
					<u-form-item label="学生电话" prop="userInfo.phone" borderBottom ref="item3">
						<u--input v-model="model1.userInfo.phone" border="none" placeholder="132****0000"></u--input>
					</u-form-item>
					<u-form-item label="帮扶类别" prop="userInfo.classify" borderBottom
						@click="showSex = true; hideKeyboard()" ref="item4">
						<u--input v-model="model1.userInfo.classify" disabled disabledColor="#ffffff"
							placeholder="请选择类别" border="none"></u--input>
						<u-icon slot="right" name="arrow-right"></u-icon>
					</u-form-item>
					<u-form-item label="就业与否" prop="employment" borderBottom ref="item5">
						<u-radio-group v-model="model1.employment">
							<u-radio :customStyle="{marginRight: '16px'}" v-for="(item, index) in radiolist1"
								:key="index" :label="item.name" :name="item.name">
							</u-radio>
						</u-radio-group>
					</u-form-item>
					<u-form-item label="" prop="userInfo.image" borderBottom ref="item6">
						<u-upload :fileList="fileList3" @afterRead="afterRead" @delete="deletePic" name="3" multiple
							:maxCount="10" :previewFullImage="true"></u-upload>
						<!-- <u-button text="上传相关图片" size="normal" plain shape="circle" type="success"></u-button> -->
					</u-form-item>
					<u-form-item label="情况概述" prop="intro" borderBottom ref="item7">
						<u--textarea placeholder="不低于10个字" v-model="model1.intro" maxlength="300" count></u--textarea>
					</u-form-item>
				</u--form>
				<button type="submit" class="customBtn btn1" click="reset">重置</button>
				<button type="submit" class="customBtn btn2" @click="submit">提交</button>
				<u-action-sheet :show="showSex" :actions="actions" title="请选择帮扶类别" description="如果选择其他会报错"
					@close="showSex = false" @select="sexSelect">
				</u-action-sheet>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				fileList1: [],
				disabled1: false,
				tips: '',
				value: '',
				fileList3: [
					// 	{
					// 	url: 'https://cdn.uviewui.com/uview/swiper/1.jpg',
					// }, 
				],
				showCalendar: false,
				showBirthday: false,
				model1: {
					userInfo: {
						name: '',
						classify: '',
						birthday: '',
						department: '',
						phone: '',
						image: '',
					},
					employment: '否',
					checkboxValue1: [],
					intro: '',
					code: ''
				},
				showSex: false,
				birthday: Number(new Date()),
				actions: [{
						name: '经济困难家庭',
					},
					{
						name: '学业辅导',
					},
					{
						name: '就业求助',
					},
					{
						name: '社区帮扶',
					},
					{
						name: '其他',
					},
				],
				rules: {
					'userInfo.name': [{
						type: 'string',
						required: true,
						message: '请填写姓名',
						trigger: ['blur', 'change']
					}, {
						// 此为同步验证，可以直接返回true或者false，如果是异步验证，稍微不同，见下方说明
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return uni.$u.test.chinese(value);
						},
						message: "姓名必须为中文",
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ["change", "blur"],
					}],
					'userInfo.department': [{
						type: 'string',
						required: true,
						message: '请填写专业班级',
						trigger: ['blur', 'change']
					}, {
						// 此为同步验证，可以直接返回true或者false，如果是异步验证，稍微不同，见下方说明
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							// return uni.$u.test.chinese(value);
							if (value.length <= 3) {
								return false
							}
							return true
						},
						message: "不少于4个字",
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ["change", "blur"],
					}],
					'userInfo.classify': {
						type: 'string',
						min: 2,
						required: true,
						message: '请选择帮扶类别',
						trigger: ['blur', 'change']
					},
					'userInfo.phone': [{
						type: 'string',
						required: true,
						message: '请填写手机号',
						trigger: ['blur', 'change']
					}, {
						// 此为同步验证，可以直接返回true或者false，如果是异步验证，稍微不同，见下方说明
						validator: (rule, value, callback) => {
							// 调用uView自带的js验证规则，详见：https://www.uviewui.com/js/test.html
							return uni.$u.test.mobile(value);
						},
						message: "请填写正确手机号",
						// 触发器可以同时用blur和change，二者之间用英文逗号隔开
						trigger: ["change", "blur"],
					}],
					code: {
						type: 'string',
						required: true,
						len: 4,
						message: '请填写4位验证码',
						trigger: ['blur']
					},
					'userInfo.classify': {
						type: 'string',
						min: 2,
						required: true,
						message: '请选择帮扶类别',
						trigger: ['blur', 'change']
					},
					checkboxValue1: {
						type: 'array',
						min: 2,
						required: true,
						message: '不能太宅，至少选两项',
						trigger: ['change']
					},
					intro: {
						type: 'string',
						min: 10,
						required: true,
						message: '不低于10个字',
						trigger: ['change']
					},
					hotel: {
						type: 'string',
						min: 2,
						required: true,
						message: '请选择住店时间',
						trigger: ['change']
					},
					'userInfo.birthday': {
						type: 'string',
						required: true,
						message: '请选择生日',
						trigger: ['change']
					},
				},
				radiolist1: [{
						name: '否',
						disabled: false
					},
					{
						name: '是',
						disabled: false
					}
				],
				checkboxList1: [{
						name: '羽毛球',
						disabled: false
					},
					{
						name: '跑步',
						disabled: false
					},
					{
						name: '爬山',
						disabled: false
					}
				]
			}
		},
		onReady() {
			// 如果需要兼容微信小程序，并且校验规则中含有方法等，只能通过setRules方法设置规则
			this.$refs.form1.setRules(this.rules)
		},
		methods: {
			afterRead(event) {
				this.fileList1.push({
					url: event.file,
					status: 'uploading',
					message: '上传中'
				})
			},
			groupChange(n) {
				// console.log('groupChange', n);
			},
			radioChange(n) {
				// console.log('radioChange', n);
			},
			navigateBack() {
				uni.navigateBack()
			},
			sexSelect(e) {
				this.model1.userInfo.classify = e.name
				this.$refs.form1.validateField('userInfo.classify')
			},
			change(e) {
				// console.log(e);
			},
			formatter(day) {
				const d = new Date()
				let month = d.getMonth() + 1
				const date = d.getDate()
				if (day.month == month && day.day == date + 3) {
					day.bottomInfo = '有优惠'
					day.dot = true
				}
				return day
			},
			calendarConfirm(e) {
				this.showCalendar = false
				this.model1.hotel = `${e[0]} / ${e[e.length - 1]}`
				this.$refs.form1.validateField('hotel')
			},
			codeChange(text) {
				this.tips = text;
			},
			getCode() {
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: '正在获取验证码'
					})
					setTimeout(() => {
						uni.hideLoading();
						// 这里此提示会被this.start()方法中的提示覆盖
						uni.$u.toast('验证码已发送');
						// 通知验证码组件内部开始倒计时
						this.$refs.uCode.start();
					}, 2000);
				} else {
					uni.$u.toast('倒计时结束后再发送');
				}
			},
			calendarClose() {
				this.showCalendar = false
				this.$refs.form1.validateField('hotel')
			},
			birthdayClose() {
				this.showBirthday = false
				this.$refs.form1.validateField('userInfo.birthday')
			},
			birthdayConfirm(e) {
				this.showBirthday = false
				this.model1.userInfo.birthday = uni.$u.timeFormat(e.value, 'yyyy-mm-dd')
				this.$refs.form1.validateField('userInfo.birthday')
			},
			submit() {
				// 如果有错误，会在catch中返回报错信息数组，校验通过则在then中返回true
				this.$refs.form1.validate().then(res => {
					uni.$u.toast('校验通过')
				}).catch(errors => {
					uni.$u.toast('校验失败')
				})
			},
			reset() {
				const validateList = ['userInfo.name', 'userInfo.classify', 'employment', 'checkboxValue1', 'intro',
					'hotel', 'code', 'userInfo.birthday'
				]
				this.$refs.form1.resetFields()
				this.$refs.form1.clearValidate()
				setTimeout(() => {
					this.$refs.form1.clearValidate(validateList)
					// 或者使用 this.$refs.form1.clearValidate()
				}, 10)
			},
			hideKeyboard() {
				uni.hideKeyboard()
			},
			// 删除图片
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
						status: 'uploading',
						message: '上传中'
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
		}
	}
</script>

<style lang="scss">
	.content {
		padding: 0rpx 40rpx;
		height: 100vh;
		background-color: white;
	}

	.u-demo-block__title {
		color: #c70a0e;
		font-size: 24rpx;
		line-height: 50rpx;
	}

	.customBtn {
		width: 300rpx;
		line-height: 50rpx;
		margin-left: 30rpx;
		margin-top: 80rpx;
	}

	.btn1 {
		background-color: #C0B0B0;
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
	}

	.btn2 {
		background-color: #F54E4E;
		/* Green */
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
	}
</style>