<template>
	<view class="container">
		<!-- 地图 -->
		<!-- <mapdemo></mapdemo> -->
		<view class="dataEntrance">
			<view>
				<u-grid :border="false" align="center" @click="click">
					<u-grid-item v-for="(listItem,listIndex) in list" :key="listIndex"
						customStyle="padding-top: 10px; padding-bottom: 10px">
						<image :src="listItem.url" mode=""></image>
						<text class="grid-text">{{listItem.title}}</text>
					</u-grid-item>
				</u-grid>
			</view>
		</view>
		<view class="adminShow">
			<text>递交入党申请书情况</text>
			<u-tabs :list="tablist" :is-scroll="false" :current="current" bar-width="50" swipeable
				active-color="#30B1B7" @change="change"></u-tabs>
			<view v-if="current == 0">
				<view class="charts-box">
					<qiun-data-charts type="rose" :opts="opts4" :chartData="chartData4" />
				</view>
			</view>
			<view v-if="current == 1">
				<qiun-data-charts type="column" :opts="opts5" :chartData="chartData5" :ontouch="true" />
			</view>
			<view v-if="current == 2">
				<qiun-data-charts type="mix" :opts="opts6" :chartData="chartData6" />
			</view>
			<view v-if="current == 3">
				<qiun-data-charts type="bubble" :opts="opts7" :chartData="chartData7" />
			</view>
			<view v-if="current == 4">
				<qiun-data-charts 
				      type="arcbar"
				      :opts="opts8"
				      :chartData="chartData8"
				    />
			</view>

		</view>
		<view class="underline-text">
			<text>发展党员培养教育</text>
		</view>
		<view class="dataEntrance">
			<text>活动参与率</text>
			<view class="charts-box">
				<qiun-data-charts type="line" :opts="opts1" :chartData="chartData1" />
			</view>
		</view>
		<view class="dataEntrance">
			<text>学业分析</text>
			<view class="charts-box">
				<qiun-data-charts type="column" :opts="opts2" :chartData="chartData2" />
			</view>
		</view>

		<view class="dataEntrance">
			<text>风采展示</text>
			<view class="charts-box">
				<qiun-data-charts type="radar" :opts="opts3" :chartData="chartData3" />
			</view>
		</view>
	</view>
</template>

<script>
	import mapdemo from './mapdemo.vue'
	export default {
		data() {
			return {
				tablist: [{
						name: "0"
					},
					{
						name: "1"
					},
					{
						name: "2"
					},
					{
						name: "3"
					},
					{
						name: "4"
					},
				],
				current: 0,
				pages: [
					'/pages/memberData/finance',
					'/pages/memberData/thingInternet',
					'/pages/memberData/software',
					'/pages/memberData/telecommunication',
					'/pages/memberData/teachingStaff',
					'/pages/memberData/partyCommittee'
				],
				list: [
					{
						url: '../../static/images/政府党委.png',
						title: '党委',
					},
					{
						url: '../../static/images/金融.png',
						title: '金融支部',
					},
					{
						url: '../../static/images/物联 网-物联网平台-面.png',
						title: '物联网支部',
					},
					{
						url: '../../static/images/007_软件开发.png',
						title: '软件支部',
					},
					{
						url: '../../static/images/电信.png',
						title: '电信支部',
					},
					{
						url: '../../static/images/部门教工信息.png',
						title: '教工支部',
					},
				],
				chartData1: {},
				chartData: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['line'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts1: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 10, 0, 15],
					enableScroll: false,
					legend: {},
					xAxis: {
						disableGrid: true
					},
					yAxis: {
						gridType: "dash",
						dashLength: 2
					},
					extra: {
						line: {
							type: "curve",
							width: 2,
							activeType: "hollow"
						}
					}
				},
				chartData2: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['column'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts2: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 5],
					enableScroll: false,
					legend: {},
					xAxis: {
						disableGrid: true
					},
					yAxis: {
						data: [{
							min: 0
						}]
					},
					extra: {
						column: {
							type: "group",
							width: 30,
							activeBgColor: "#000000",
							activeBgOpacity: 0.08
						}
					}
				},
				chartData3: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['radar'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts3: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					dataLabel: false,
					enableScroll: false,
					legend: {
						show: true,
						position: "right",
						lineHeight: 25
					},
					extra: {
						radar: {
							gridType: "circle",
							gridColor: "#CCCCCC",
							gridCount: 3,
							opacity: 0.2,
							max: 200,
							labelShow: true
						}
					}
				},
				chartData4: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['rose'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts4: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					enableScroll: false,
					legend: {
						show: true,
						position: "left",
						lineHeight: 25
					},
					extra: {
						rose: {
							type: "radius",
							minRadius: 50,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 2,
							borderColor: "#FFFFFF",
							linearType: "custom"
						}
					}
				},
				chartData5: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['column'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts5: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 5],
					touchMoveLimit: 24,
					enableScroll: true,
					legend: {},
					xAxis: {
						disableGrid: true,
						scrollShow: true,
						itemCount: 4
					},
					yAxis: {
						data: [{
							min: 0
						}]
					},
					extra: {
						column: {
							type: "group",
							width: 30,
							activeBgColor: "#000000",
							activeBgOpacity: 0.08
						}
					}
				},
				chartData6: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['mix'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts6: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 15],
					enableScroll: false,
					legend: {},
					xAxis: {
						disableGrid: true,
						title: "单位：年"
					},
					yAxis: {
						disabled: false,
						disableGrid: false,
						splitNumber: 5,
						gridType: "dash",
						dashLength: 4,
						gridColor: "#CCCCCC",
						padding: 10,
						showTitle: true,
						data: [{
								position: "left",
								title: "折线"
							},
							{
								position: "right",
								min: 0,
								max: 200,
								title: "柱状图",
								textAlign: "left"
							},
							{
								position: "right",
								min: 0,
								max: 200,
								title: "点",
								textAlign: "left"
							}
						]
					},
					extra: {
						mix: {
							column: {
								width: 20
							}
						}
					}
				},
				chartData7: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['bubble'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts7: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 15],
					enableScroll: false,
					legend: {},
					xAxis: {
						disableGrid: false,
						gridType: "dash",
						splitNumber: 5,
						boundaryGap: "justify",
						min: 0,
						max: 250
					},
					yAxis: {
						disableGrid: false,
						gridType: "dash",
						data: [{
							min: 0,
							max: 150
						}]
					},
					extra: {
						bubble: {
							border: 2,
							opacity: 0.5
						}
					}
				},
			chartData8: {},
			      //您可以通过修改 config-ucharts.js 文件中下标为 ['arcbar'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
			      opts8: {
			        color: ["#1890FF","#91CB74","#FAC858","#EE6666","#73C0DE","#3CA272","#FC8452","#9A60B4","#ea7ccc"],
			        padding: undefined,
			        title: {
			          name: "各年级",
			          fontSize: 35,
			          color: "#1890ff"
			        },
			        subtitle: {
			          name: "入党申请人数",
			          fontSize: 15,
			          color: "#666666"
			        },
			        extra: {
			          arcbar: {
			            type: "circle",
			            width: 12,
			            backgroundColor: "#E9E9E9",
			            startAngle: 1.5,
			            endAngle: 0.25,
			            gap: 2
			          }
			        }
			      }
			};
		},
		onReady() {
			this.getServerData();
		},
		components: {
			mapdemo
		},
		methods: {
			click(count) {
				uni.navigateTo({
					url: `${this.pages[count]}`,
				});
			},
			change(index) {
				this.current = index.index;
				//如报错则用this.current = index代替上行
			},
			getServerData() {
				//模拟从服务器获取数据时的延时
				setTimeout(() => {
					//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
					let res1 = {
						categories: ["2018", "2019", "2020", "2021", "2022", "2023"],
						series: [{
								name: "成交量A",
								lineType: "dash",
								data: [35, 8, 25, 37, 4, 20]
							},
							{
								name: "成交量B",
								data: [70, 40, 65, 100, 44, 68]
							},
							{
								name: "成交量C",
								data: [100, 80, 95, 150, 112, 132]
							}
						]
					};
					this.chartData1 = JSON.parse(JSON.stringify(res1));

					let res2 = {
						categories: ["2018", "2019", "2020", "2021", "2022", "2023"],
						series: [{
								name: "目标值",
								data: [35, 36, 31, 33, 13, 34]
							},
							{
								name: "完成量",
								data: [18, 27, 21, 24, 6, 28]
							}
						]
					};
					this.chartData2 = JSON.parse(JSON.stringify(res2));

					let res3 = {
						categories: ["维度1", "维度2", "维度3", "维度4", "维度5", "维度6"],
						series: [{
								name: "成交量1",
								data: [90, 110, 165, 195, 187, 172]
							},
							{
								name: "成交量2",
								data: [190, 210, 105, 35, 27, 102]
							}
						]
					};
					this.chartData3 = JSON.parse(JSON.stringify(res3));

					let res4 = {
						series: [{
							data: [{
								"name": "一班",
								"value": 50
							}, {
								"name": "二班",
								"value": 30
							}, {
								"name": "三班",
								"value": 20
							}, {
								"name": "四班",
								"value": 18
							}, {
								"name": "五班",
								"value": 8
							}]
						}]
					};
					this.chartData4 = JSON.parse(JSON.stringify(res4));

					let res5 = {
						categories: ["2018", "2019", "2020", "2021", "2022", "2023"],
						series: [{
								name: "目标值",
								data: [35, 36, 31, 33, 13, 34]
							},
							{
								name: "完成量",
								data: [18, 27, 21, 24, 6, 28]
							}
						]
					}
					this.chartData5 = JSON.parse(JSON.stringify(res5));

					let res6 = {
						categories: ["2018", "2019", "2020", "2021", "2022", "2023"],
						series: [{
								name: "曲面",
								type: "area",
								style: "curve",
								data: [70, 50, 85, 130, 64, 88]
							},
							{
								name: "柱1",
								index: 1,
								type: "column",
								data: [40, {
									"value": 30,
									"color": "#f04864"
								}, 55, 110, 24, 58]
							},
							{
								name: "柱2",
								index: 1,
								type: "column",
								data: [50, 20, 75, 60, 34, 38]
							},
							{
								name: "曲线",
								type: "line",
								style: "curve",
								color: "#1890ff",
								disableLegend: true,
								data: [70, 50, 85, 130, 64, 88]
							},
							{
								name: "折线",
								type: "line",
								color: "#2fc25b",
								data: [120, 140, 105, 170, 95, 160]
							},
							{
								name: "点",
								index: 2,
								type: "point",
								color: "#f04864",
								data: [100, 80, 125, 150, 112, 132]
							}
						]
					};
					this.chartData6 = JSON.parse(JSON.stringify(res6));

					let res7 = {
						series: [{
								name: "气泡一",
								data: [
									[95, 95, 23, "标题1"],
									[30, 55, 33, "标题2"]
								]
							},
							{
								name: "气泡二",
								data: [
									[130, 30, 30, "标题3"],
									[200, 90, 40, "标题4"]
								]
							}
						]
					};
					this.chartData7 = JSON.parse(JSON.stringify(res7));
					
			let res8 = {
			            series: [
			              {
			                name: "一班",
			                data: 0.8
			              },
			              {
			                name: "二班",
			                data: 0.6
			              },
			              {
			                name: "三班",
			                data: 0.45
			              },
			              // {
			              //   name: "四班",
			              //   data: 0.3
			              // },
			              // {
			              //   name: "五班",
			              //   data: 0.15
			              // }
			            ]
			          };
			        this.chartData8 = JSON.parse(JSON.stringify(res8));
				}, 500);
			}
		}

	}
</script>

<style scoped>
	.underline-text {
		position: relative;
		line-height: 60rpx;
		margin: 20rpx 10rpx 10rpx 10rpx;
		display: inline-block;
		/* 确保块级元素也能应用下划线 */
	}

	/* 使用伪元素添加下划线 */
	.underline-text::after {
		content: '';
		/* 伪元素必须有内容 */
		position: absolute;
		bottom: 0;
		/* 下划线位于文字底部 */
		left: 0;
		width: 100%;
		/* 横跨整个文本 */
		height: 13rpx;
		/* 下划线厚度 */
		opacity: 25%;
		padding: 10rpx 0rpx 5rpx 0rpx;
		margin-left: 30rpx;
		width: 150rpx;
		background-color: red;
		/* 下划线颜色 */
	}

	/* .dataEntrance {
		background-color: white;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		justify-content: center;
	}

	.entrance {
		margin: 50rpx;
		text-align: center;
	}

	.entrance text,
	.entrance image {
		vertical-align: middle;
		display: inline-block;
	} */

	.dataEntrance {
		background-color: white;
		margin: 30rpx 15rpx;
		padding: 20rpx;
		border-radius: 20rpx;
	}

	.dataEntrance image {
		height: 80rpx;
		width: 80rpx;
	}

	.grid-text {
		font-size: 14px;
		color: #909399;
		padding: 10rpx 0 20rpx 0rpx;
		/* #ifndef APP-PLUS */
		box-sizing: border-box;
		/* #endif */
	}

	/* .dataEntrance text {
		background-color: chocolate;
	} */
	.u-tabs {
		color: black;
	}

	.adminShow {
		margin: 10rpx;
		padding: 20rpx;
		border: 1rpx solid #b8bcc3;
		border-radius: 20rpx;
	}
</style>